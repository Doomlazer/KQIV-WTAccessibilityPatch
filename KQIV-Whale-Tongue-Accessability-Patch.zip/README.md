# KQIV Whale Tongue Accessibility Patch
 
Verion 1.0.1

This replaces the control pic of the whale's belly making it trivial to climb. It also fixes a bug in the original game that would otherwise cause a lock up when falling off the top of the tongue.

Developed using <a href="http://scicompanion.com/">SCI Companion</a>

Installation:

Copy pic.044 and script.044 into your KQIV game folder and start the game normally. Uninstall by removing the files.

<img src="before.png"  width="500">
<img src="after.png" width="500">
https://github.com/Doomlazer/KQIV-Whale-Tongue-Accessability-Patch
